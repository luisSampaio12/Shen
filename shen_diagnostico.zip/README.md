# SHEN Diagnóstico

Sistema completo de diagnóstico clínico com espectrofotometria e IA.

## Instalação

1. `pip install -r requirements.txt`
2. `python run.py`

Acesse `http://localhost:5000`
